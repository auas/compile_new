#include "midCode.h"
#include "add.h"
using namespace std;


genTmpVar::genTmpVar(){
  num = 0;
}
string genTmpVar::getName(){
    //cout<<"start get tmp name"<<endl;
    string ret;
    char tmp[100];
    sprintf(tmp,"%d",num);
    string temp1(tmp);
    num++;
    ret = nameHead+temp1;
    return ret;
}
void genTmpVar::getTmpVar(symbolTab* tmp){ //Ĭ��Ϊint ���͵ı���
    string name = getName();
    tmp->name = name;
    //cout<<"%%&&^^%%"<<name<<endl;
    tmp->cat = 2;
    tmp->typ = 1;
    tmp->ref = 0;
}

genLabel::genLabel(){
  num = 0;
}
string genLabel::getName(){
  //cout<<"start get tmp name"<<endl;
  string ret;
  char tmp[100];
  sprintf(tmp,"%d",num);
  string temp1(tmp);
  num++;
  ret = nameHead+temp1;
  return ret;
}
void genLabel::getLabel(symbolTab* tmp){
  string name = getName();
  tmp->name = name;
  tmp->cat = 0;
  tmp->typ = 0;
  tmp->ref = 0;
}



int codeTpy(string op){
    return 0; // to fix!
}


midCodeFunc::midCodeFunc(){
  a = 0;
}
void midCodeFunc::gen_mid_code(string op,symbolTab* sr1){
  midCode* tmp_code = &(mytab.ctab[mytab.ctl_idx]);
  tmp_code->op = op;
  tmp_code->sr1 = sr1;
  tmp_code->typ = 1;
  mytab.ctl_idx++;

}
void midCodeFunc::gen_mid_code(string op,symbolTab* sr1,symbolTab* sr2){
  cout<<"hahahah"<<endl;
  midCode* tmp_code = &(mytab.ctab[mytab.ctl_idx]);
  tmp_code->op = op;
  tmp_code->sr1 = sr1;
  tmp_code->sr2 = sr2;
  tmp_code->typ = 2;
  cout<<"************"<<tmp_code->op.c_str()<<endl;
  cout<<"$$$$$$$$$$$$$$$$$$$$$$   "<<sr1->name.c_str()<<endl;
  cout<<"$$$$$$$$$$$$$$$$$$$$$$   "<<sr2->name.c_str()<<endl;
  mytab.ctl_idx++;
  /*
  switch(op):
    case "set_I":{
      tmp_code->op = "set_I";
      tmp_code->sr1 = sr1;
      tmp_code->dst = dst;
      mytab.ctl_idx++;
      break;
    }
  */

  //mytab.ctl_idx++;
}
void midCodeFunc::gen_mid_code(string op,symbolTab* sr1,symbolTab* sr2,symbolTab* dst){
  midCode* tmp_code = &(mytab.ctab[mytab.ctl_idx]);
  tmp_code->op = op;
  tmp_code->sr1 = sr1;
  tmp_code->sr2 = sr2;
  tmp_code->dst = dst;
  tmp_code->typ = 3;
  mytab.ctl_idx++;
  /*
  switch(op):
    case "get_array":{
      tmp_code->op = "get_array";
      tmp_code->sr1 = sr1;
      tmp_code->sr2 = sr2;
      tmp_code->dst = dst;
      mytab.ctl_idx++;
      break;
    }
    case "times":{
      tmp_code->op = "times";
      tmp_code->sr1 = sr1;
      tmp_code->sr2 = sr2;
      tmp_code->dst = dst;
      mytab.ctl_idx++;
      break;
    }
    //mytab.ctl_idx++;
  */
}
